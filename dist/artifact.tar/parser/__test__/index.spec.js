const parser = require('..')
const ACTIONS = require('../actions')

describe('Language parser test', function () {
  it('should parse cmd correctly')
})
