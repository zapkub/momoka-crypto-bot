# Simple Line BX Monitor bot

## Setup
- Create Line bussiness account
- Create Line Bot account and setup webhook in Line management
- create .env file from .env.example