
describe('etc strategy test', () => {
  it('should send nude for nude ', async () => {
  })
})
