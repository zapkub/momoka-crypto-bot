
describe('Bx strategy test', () => {
  it('should getPriceInfo from bx api', async () => {
  })
})
